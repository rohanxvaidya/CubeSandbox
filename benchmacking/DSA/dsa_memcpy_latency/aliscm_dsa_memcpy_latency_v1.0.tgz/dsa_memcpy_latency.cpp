#include <dirent.h>
#include <fcntl.h>
#include <pthread.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <sys/time.h>
#include <time.h>
#include <unistd.h>
#include <algorithm>
#include <vector>
#include <linux/idxd.h>
#include <x86intrin.h>
#include <libpmem.h>
//#include <libpmem2.h>

#define TSC_GHZ 3   // assume it's 3, need to check the system if you want to more accurate.
#define DSA_BENCH_VERSION   "1.0"


static size_t block_size = 4 * 1024ULL;
static char dev_path[512];
static char dsa_wq_path[512];
static void* dsa_wq_portal;
static size_t iteration = 10000ULL;
static size_t dev_size = 1024ULL * 1024ULL * 1024ULL;
static char* device_mem_ptr;
static int is_write = 0;
static int cpu_num = 0;
static int use_mem = 0;
static size_t iodepth = 1;
static int data_model = 0;  // 0- both header + DATA; 1- only header;  2 - only DATA;

static size_t submit_retry = 0;
static uint32_t idle_interval = 10;
static int do_with_cpu = 0;
static uint32_t print_threshold = 16000;    //only print the latency value large than 16us 
static uint32_t usleep_time  = 30;   //by default sleep 30us between two ops;
static int mlock_enable = 1;
static int use_tsc = 1;
static int with_fence = 0;
static int debug_mode = 0;
static int wq_portal_sw = 0;
static int wait_function = 0;   // 0- usleep ; 1- busyloop.
static int dedicated_wq = 0;    //shared wq; dedicated wq;

typedef struct {
    struct dsa_completion_record comp __attribute__((aligned(64)));
    struct dsa_hw_desc desc __attribute__((aligned(64)));
} dsa_task_t; // 96 bytes

// typedef struct {
//     struct dsa_completion_record comp;
//     struct dsa_hw_desc desc;
// } dsa_task_t; // 96 bytes



#define TSCRD1	"lfence; rdtsc;"
#define TSCRD10 TSCRD1 TSCRD1 TSCRD1 TSCRD1 TSCRD1 TSCRD1 TSCRD1 TSCRD1 TSCRD1 TSCRD1 
#define TSCRD100 TSCRD10 TSCRD10 TSCRD10 TSCRD10 TSCRD10 TSCRD10 TSCRD10 TSCRD10 TSCRD10 TSCRD10 

uint32_t rdtsc_overhead = 0;

#define THE_TSC rdtsc()
static inline unsigned long
rdtsc()
{
	unsigned long var;
	unsigned int hi, lo;
	asm volatile(
		"lfence\n\r"
		"rdtsc\n\r" 
		: "=a"(lo), "=d"(hi));
	var = ((unsigned long long int) hi << 32) | lo;
	return var;
}

uint32_t rdtsc_latency() {
    uint64_t a, b;
    
    a = THE_TSC;
    asm (
        TSCRD100
        TSCRD100
    :: );
    b = THE_TSC;
    return (uint32_t)((b-a)/200);
}
     
uint32_t compute_rdtsc_latency()
{
    uint32_t oh=0xffffff, result=0;
    for (int i=0; i < 4; i++) {
        result = rdtsc_latency();
        if (result < oh) oh = result;
    }
    //printf("overhead = %d\n", result);
    return result;
    
}

/* hold_count cycles. */
void busy_loop_cycle_delay(int hold_count)
{
    uint64_t begin, end;
  
    if (hold_count==0) 
        return;

    begin = THE_TSC;
 
    while(1)
    {
        _mm_pause();
        end = THE_TSC;
        if ((end-begin) >= (uint64_t)hold_count - 2*rdtsc_overhead)
            break;
    }
 
}

static uint64_t inline get_rdtscp(void) {
    uint32_t lo, hi;
    __asm__ __volatile__ (
        "rdtscp" : "=a" (lo), "=d" (hi) :: "%rcx"
    );
    return ((uint64_t)hi << 32) | lo;
}

static __always_inline unsigned char enqcmd(void* dst, const void* src) {
    unsigned char ret;

    asm volatile(".byte 0xf2, 0x0f, 0x38, 0xf8, 0x02\t\n"
                 "setz %0\t\n"
                 : "=r"(ret)
                 : "a"(dst), "d"(src));
    return ret;
}

static __always_inline void movdir64b(void* dst, const void* src) {
    asm volatile(".byte 0x66, 0x0f, 0x38, 0xf8, 0x02\t\n"
                 :
                 : "a"(dst), "d"(src));
}

static uint8_t dsa_status(uint8_t status) {
    return status & DSA_COMP_STATUS_MASK;
}

static __always_inline uintptr_t
next_cache_line(uintptr_t curr_addr)
{
	uintptr_t off = curr_addr & 0xfff;
	uintptr_t base = curr_addr & ~0xfff;

	off += 0x40;
	off &= 0xfff;

	return base + off;
}

static __always_inline void *
incr_portal_addr(void *curr_portal_addr)
{
		return (void *)(next_cache_line((uintptr_t)curr_portal_addr));
}

static __always_inline int dsa_desc_submit(void* wq_portal,
                           struct dsa_hw_desc* hw) {
    size_t retry = 0;

    if (with_fence) {
        /* ensure previous writes are ordered */
        _mm_sfence();
    }
    //printf("wq addr before %p \n", wq_portal);
    if (dedicated_wq) {
        movdir64b(wq_portal, hw);
    } else {
        while (enqcmd(wq_portal, hw)) {
            if (retry++ > 10000ULL) {
                return 1;
            }
        }
    }


    submit_retry += retry;

    return 0;
}

static __always_inline void dsa_retry_prep(struct dsa_hw_desc* desc,
                           struct dsa_completion_record* comp) {
    int is_write = comp->status & DSA_COMP_STATUS_WRITE;
    volatile char* addr;

    addr = (char*)comp->fault_addr;
    is_write ? * addr = *addr : *addr;

    desc->src_addr += comp->bytes_completed;
    desc->dst_addr += comp->bytes_completed;
    desc->xfer_size -= comp->bytes_completed;

    comp->status = DSA_COMP_NONE;
}

static void* mmap_dsa_wq(const char* dsa_wq_path) {
    int fd = open(dsa_wq_path, O_RDWR);
    if (fd < 0) {
        printf("failed to open %s", dsa_wq_path);
        return NULL;
    }

    void* wq_portal =
        mmap(NULL, 0x1000, PROT_WRITE, MAP_SHARED | MAP_POPULATE, fd, 0);
    if (wq_portal == MAP_FAILED) {
        printf("failed to mmap %s", dsa_wq_path);
        close(fd);
        return NULL;
    }

    close(fd);
    return wq_portal;
}

static void print_usage() {
    printf("\tOptions: (V%s). ", DSA_BENCH_VERSION);
    printf("This tool is used for testing dsa memmove latency\n");
    printf("\t[-d dax device path]\n");
    printf("\t[-s dax device size]\n");
    printf("\t[-b memcpy block size]\n");
    printf("\t[-i memcpy iteration number]\n");
    printf("\t[-k bind cpu num]\n");
    printf("\t[-w write from local memory to device, otherwise read]\n");
    printf("\t[-q dsa wq path, e.g. /dev/dsa/wq0.0]\n");
    printf("\t[-o iodepth, defined request depth in each operaton iteration]\n");
    printf("\t[-C memcpy operator: 0-DSA; 1-CPU glibc memcpy; 2-CPU libpmem, NT store; ]\n");  
    printf("\t[-D Data Model for operation; 0- 4k header + 16k header; 1 - only 4k header; 2 - only 16k data]\n");
    printf("\t[-I usleep interval, i.e. -I 10, then compete 10 ops, will have x us sleep ]\n");  
    printf("\t[-T print threshold (ns), only print the latency large than this threshold ]\n");  
    printf("\t[-S sleep time(us) between two OPs ]\n");  
    printf("\t[-F Enable fence before submit; bydefault it's disabled. Enable it if BOF is enabled.]\n");  
    printf("\t[-g debug mode, 0-logging whole ops; 1-logging each phase; bydefault 0 ]\n"); 
    printf("\t[-P Enable DSA WQ portal address increase (switch with round robin in 4k)  ]\n");
    printf("\t[-W Wait function, 0: usleep or 1: busy loop. bydefault is 0; ]\n");
}

static void mmap_device(const char* dev_path, unsigned long long dev_size) {
    if (!use_mem) {
        int device_fd = open(dev_path, O_RDWR, 0666);
        if (device_fd < 0) {
            fprintf(stderr, "Failed to open %s\n", dev_path);
            _exit(1);
        }

        device_mem_ptr = (char*)mmap(NULL, dev_size, PROT_WRITE | PROT_READ,
                                     MAP_SHARED, device_fd, 0);
        if (device_mem_ptr == MAP_FAILED) {
            fprintf(stderr, "Failed to mmap %s, ptr is %p\n", dev_path,
                    device_mem_ptr);
            close(device_fd);
            _exit(1);
        }
    } else {
        device_mem_ptr = (char*)mmap(NULL, dev_size, PROT_WRITE | PROT_READ,
                                     MAP_ANONYMOUS | MAP_PRIVATE, -1, 0);
    }

    if (mlock_enable && device_mem_ptr != NULL) {
        memset(device_mem_ptr, 0x5A, dev_size);
        mlock(device_mem_ptr, dev_size);
    }
}

static int parse_args(int argc, char* argv[]) {
    int opt;

    while ((opt = getopt(argc, argv, "b:C:d:D:g:i:I:k:q:s:S:T:o:W:FtLwmhPQ")) != -1) {
        switch (opt) {
        case 'b':
            block_size = strtoull(optarg, NULL, 10);
            break;
        case 'd':
            strncpy(dev_path, optarg, sizeof(dev_path));
            break;
        case 'i':
            iteration = strtoull(optarg, NULL, 10);
            break;
        case 'q':
            strncpy(dsa_wq_path, optarg, sizeof(dsa_wq_path));
            break;
        case 's':
            dev_size = strtoull(optarg, NULL, 10);
            break;
        case 'w':
            is_write = 1;
            break;
        case 'W':
            wait_function = atoi(optarg);
            if (wait_function >= 1)
                wait_function = 1;
            break;
        case 'k':
            cpu_num = atoi(optarg);
            break;
        case 'g':
            debug_mode = atoi(optarg);
            break;
        case 'm':
            use_mem = 1;
            break;
        case 'L':
            mlock_enable = 1;
            break;
        case 't':
            use_tsc = 1;
            break;
        case 'F':
            with_fence = 1;
            break;
        case 'P':
            wq_portal_sw = 1;
            break;
        case 'Q':
            dedicated_wq = 1;
            break;
        case 'D':
            data_model = atoi(optarg);
            break;
        case 'I':
            idle_interval = atoi(optarg);
            break;
        case 'o':
            iodepth = strtoull(optarg, NULL, 10);
            break;
        case 'C':
            do_with_cpu = atoi(optarg);
            break;
        case 'S':
            usleep_time = atoi(optarg);
            break;
        case 'T':
            print_threshold = atoi(optarg);
            if (print_threshold <= 0 )
                print_threshold = 16000;
            break;
        case 'h':
            print_usage();
            return 1;
        default:
            print_usage();
            return 1;
        }
    }

    return 0;
}

static int generate_index(size_t block_num) {
    int index = rand() % block_num;

    return index;
}

void* task(void* args) {
    size_t block_num = dev_size / (block_size + 4096);
    size_t body_buffer_size = block_size * iodepth * 2;
    char* buffer = (char*)malloc(body_buffer_size);
    char* header_buffer = (char*)malloc(4096);
    size_t finished_task_num = 0;
    char* dsa_tasks_buffer;
    size_t das_task_size = 2 * iodepth * sizeof(dsa_task_t);
    struct timeval start, end, begin;

    uint64_t t0_begin = 0, t1_start = 0, t2_end = 0, submit1 = 0, submit2 = 0;

    if (mlock_enable && buffer != NULL) {
        mlock(buffer, body_buffer_size);
        memset(buffer, 0x5A, body_buffer_size);
    }

    if (mlock_enable && header_buffer != NULL) {
        mlock(header_buffer, 4096);
        memset(header_buffer, 0x5A, 4096);
    }

    if (posix_memalign((void**)&dsa_tasks_buffer, 0x1000,
                        das_task_size )) {
        printf("allocate dsa task buffer failed\n");
        _exit(1);
    }

    if (mlock_enable && dsa_tasks_buffer != NULL) {
        mlock(dsa_tasks_buffer, das_task_size );
    }

    mmap_device(dev_path, dev_size);
    srand(time(NULL));

    dsa_wq_portal = mmap_dsa_wq(dsa_wq_path);
    if (dsa_wq_portal == NULL) {
        printf("mmap dsa wq portal failed\n");
        _exit(1);
    }

    if (!use_tsc)
        gettimeofday(&begin, NULL);
    else 
        t0_begin = get_rdtscp();

    for (size_t i = 0; i < iteration; i++) {
        int index = generate_index(block_num);
        char* tmp_buffer = buffer;
        char* device_buffer = device_mem_ptr + index * (block_size + 4096);

        _mm_sfence();

        if (!use_tsc)
            gettimeofday(&start, NULL);
        else
            t1_start = get_rdtscp();

        // memcpy(dst, src, tcfg->blen);

        // submit header
        if (data_model == 0 || data_model == 1){

            dsa_task_t* dsa_task = (dsa_task_t*)dsa_tasks_buffer;

            dsa_task->desc.opcode = DSA_OPCODE_MEMMOVE;
            dsa_task->desc.flags = IDXD_OP_FLAG_RCR | IDXD_OP_FLAG_CRAV | IDXD_OP_FLAG_DRDBK | IDXD_OP_FLAG_BOF;
//            dsa_task->desc.flags = IDXD_OP_FLAG_RCR | IDXD_OP_FLAG_CRAV | IDXD_OP_FLAG_BOF;
            dsa_task->desc.flags = IDXD_OP_FLAG_RCR | IDXD_OP_FLAG_CRAV | IDXD_OP_FLAG_CC;
            dsa_task->desc.xfer_size = 4096;
            dsa_task->comp.status = 0;
            dsa_task->desc.completion_addr = (uint64_t)&dsa_task->comp;

            if (is_write) {
                dsa_task->desc.src_addr = (uint64_t)header_buffer;             
                dsa_task->desc.dst_addr = (uint64_t)device_buffer;
            } else {
                dsa_task->desc.src_addr = (uint64_t)device_buffer;
                dsa_task->desc.dst_addr = (uint64_t)header_buffer;
            }

            if (do_with_cpu == 1) {
                memcpy((char *) (dsa_task->desc.dst_addr), (char *) (dsa_task->desc.src_addr), dsa_task->desc.xfer_size);
            } else if (do_with_cpu == 2) {
                //void *pmem_memcpy_persist(void *pmemdest, const void *src, size_t len);
                pmem_memcpy_persist((char *) (dsa_task->desc.dst_addr), (char *) (dsa_task->desc.src_addr), dsa_task->desc.xfer_size);
            } else {
                if (dsa_desc_submit(dsa_wq_portal, &dsa_task->desc)) {
                    printf("submit task failed\n");
                    _exit(1);
                }
                //printf("wq addr before %p \n", dsa_wq_portal);
                if (wq_portal_sw) {
                    dsa_wq_portal = incr_portal_addr(dsa_wq_portal);
                }
                //printf("wq addr after %p \n", dsa_wq_portal);

                if ((debug_mode == 1) && (use_tsc == 1) )
                    submit1 = get_rdtscp() - t1_start;
            }

        }
_handler_data_submit:
        // submit data
        if (data_model == 0 || data_model == 2){

            // dsa_task_t* dsa_task2 = (dsa_task_t*)(dsa_tasks_buffer + sizeof(dsa_task_t));
            dsa_task_t* dsa_task2 = (dsa_task_t*)(dsa_tasks_buffer + 1 * sizeof(dsa_task_t));   //16k body data use second task buffer;

            dsa_task2->desc.opcode = DSA_OPCODE_MEMMOVE;
            dsa_task2->desc.flags = IDXD_OP_FLAG_RCR | IDXD_OP_FLAG_CRAV | IDXD_OP_FLAG_DRDBK | IDXD_OP_FLAG_BOF;
            dsa_task2->desc.xfer_size = block_size;
            dsa_task2->comp.status = 0;
            dsa_task2->desc.completion_addr = (uint64_t)&dsa_task2->comp;

            if (is_write) {
                dsa_task2->desc.src_addr = (uint64_t)tmp_buffer;             
                dsa_task2->desc.dst_addr = (uint64_t)(device_buffer + 4096);
            } else {
                dsa_task2->desc.src_addr = (uint64_t)(device_buffer + 4096);
                dsa_task2->desc.dst_addr = (uint64_t)tmp_buffer;
            }

            // if (dsa_desc_submit(dsa_wq_portal, &dsa_task2->desc)) {
            //     printf("submit task failed\n");
            //     _exit(1);
            // }
            if (do_with_cpu == 1) {
                memcpy((char *) (dsa_task2->desc.dst_addr), (char *) (dsa_task2->desc.src_addr), dsa_task2->desc.xfer_size);
            } else if (do_with_cpu == 2) {
                //void *pmem_memcpy_persist(void *pmemdest, const void *src, size_t len);
                pmem_memcpy_persist((char *) (dsa_task2->desc.dst_addr), (char *) (dsa_task2->desc.src_addr), dsa_task2->desc.xfer_size);
            } else {
                if (dsa_desc_submit(dsa_wq_portal, &dsa_task2->desc)) {
                    printf("submit task failed\n");
                    _exit(1);
                }
                //printf("wq addr before %p \n", dsa_wq_portal);
                if (wq_portal_sw) {
                    dsa_wq_portal = incr_portal_addr(dsa_wq_portal);
                }
                //printf("wq addr after %p \n", dsa_wq_portal);

                if ((debug_mode == 1) && (use_tsc == 1) )
                    submit2 = get_rdtscp() - t1_start;
            }
        }
        finished_task_num = 0;

        do {
            if (do_with_cpu != 0)
                break;

            if (data_model == 0 || data_model == 1){

                dsa_task_t* dsa_task = (dsa_task_t*)(dsa_tasks_buffer);

                if (dsa_status(dsa_task->comp.status) == DSA_COMP_NONE) {
                    _mm_pause();
                    _mm_pause();
                    continue;
                }

                if (dsa_status(dsa_task->comp.status) == DSA_COMP_PAGE_FAULT_NOBOF) {
                    dsa_retry_prep(&dsa_task->desc, &dsa_task->comp);

                    if (dsa_desc_submit(dsa_wq_portal, &dsa_task->desc)) {
                        printf("submit task failed\n");
                        _exit(1);
                    }

                    continue;
                }

                if (dsa_status(dsa_task->comp.status) != DSA_COMP_SUCCESS) {
                    printf("dsa task failed, status is %d\n", dsa_status(dsa_task->comp.status));
                    _exit(1);
                }

                finished_task_num++;

            }

            if (data_model == 0 || data_model == 2){

                //  dsa_task_t* dsa_task2 = (dsa_task_t*)(dsa_tasks_buffer + sizeof(dsa_task_t));
                 dsa_task_t* dsa_task2 = (dsa_task_t*)(dsa_tasks_buffer + 1 * sizeof(dsa_task_t));   //16k body data use second task buffer;

                if (dsa_status(dsa_task2->comp.status) == DSA_COMP_NONE) {
                    _mm_pause();
                    _mm_pause();

                    continue;
                }

                if (dsa_status(dsa_task2->comp.status) == DSA_COMP_PAGE_FAULT_NOBOF) {
                    dsa_retry_prep(&dsa_task2->desc, &dsa_task2->comp);

                    if (dsa_desc_submit(dsa_wq_portal, &dsa_task2->desc)) {
                        printf("submit task failed\n");
                        _exit(1);
                    }

                    continue;
                }

                if (dsa_status(dsa_task2->comp.status) != DSA_COMP_SUCCESS) {
                    printf("dsa task failed, status is %d\n", dsa_status(dsa_task2->comp.status));
                    _exit(1);
                }

                finished_task_num++;
            }

            finished_task_num = 2;
        } while (finished_task_num == 0);

        uint64_t time_elapsed = 0, running_time = 0;
        //print_threshold is nano seconds
        if (!use_tsc) {
            gettimeofday(&end, NULL);
            time_elapsed = (end.tv_sec - start.tv_sec) * 1000000 + (end.tv_usec - start.tv_usec);   // us;
            running_time = (end.tv_sec - begin.tv_sec) * 1000 +  (end.tv_usec - begin.tv_usec) /1000 ;
             // only log the latency > 1600ns;
            if (time_elapsed * 1000 > print_threshold) {
                printf("Running_timestamp: %lu ms, completed %lu OPs (%lu ops/ms), submit_retry: %lu cur_latency: %lu us\n", 
                    running_time , i, i/running_time, submit_retry, time_elapsed);
            }
        }else {
            t2_end = get_rdtscp();
            time_elapsed = (t2_end - t1_start) / TSC_GHZ;   //ns
            running_time = (t2_end - t0_begin ) /TSC_GHZ;  //ns 
            double running_time_ms = (double)running_time /1000/1000; //ms

            double cur_latency_us = (double)time_elapsed /1000;

            if (debug_mode == 1) {
                double submit1_duration_ns = 0, submit2_duration_ns = 0 ;
                if (do_with_cpu == 0) {
                    // only for DSA memcpy
                    submit1_duration_ns  = (double)submit1 / TSC_GHZ ;
                    submit2_duration_ns = (double)(submit2 - submit1) / TSC_GHZ;

                    if (submit1 == 0)
                        submit1_duration_ns = 0;
                    if (submit2 == 0)
                        submit2_duration_ns = 0; 
                }

                // only log the latency > 1600ns;
                if ((uint64_t)time_elapsed > (uint64_t)print_threshold ) {
                    printf("Running: %lu ms, completed %lu OPs(%lu ops/ms), submit1_lat[%lu ns], submit2_lat[%lu ns], dsa_wq_addr: %p, submit_retry: %lu cur_lat: %lf us\n", 
                        (uint64_t)running_time_ms, i,  
                        (uint64_t)((double)i/running_time_ms), 
                        (uint64_t)submit1_duration_ns, 
                        (uint64_t)submit2_duration_ns, 
                        dsa_wq_portal, 
                        submit_retry, 
                        cur_latency_us);
                    submit2_duration_ns = 0;
                    submit2_duration_ns = 0;
                }
            } else {
                // only log the latency > 1600ns;
                if ((uint64_t)time_elapsed > (uint64_t)print_threshold ) {
                    printf("Running: %lu ms, completed %lu OPs(%lu ops/ms), dsa_wq_addr: %p, submit_retry: %lu cur_lat: %lf us\n", 
                        (uint64_t)running_time_ms, i,  
                        (uint64_t)((double)i/running_time_ms), 
                        dsa_wq_portal, 
                        submit_retry, 
                        cur_latency_us);

                }

            }
        }

        submit_retry = 0;

        if (idle_interval > 0 && !(i % idle_interval) ) {
            if (wait_function == 1)
                busy_loop_cycle_delay(usleep_time * 1000 * TSC_GHZ);
            else 
                usleep(usleep_time);
        }
    }

    if (buffer) {
        if (mlock_enable)
            munlock(buffer, body_buffer_size);
        free(buffer);
    }

    if (dsa_tasks_buffer) {
        if (mlock_enable)
            munlock(dsa_tasks_buffer, das_task_size);
        free(dsa_tasks_buffer);
    }

    if (header_buffer) {
        if (mlock_enable)
            munlock(header_buffer, 4096);
        free(header_buffer);
    }

    if (device_mem_ptr){
        if (mlock_enable)
            munlock(device_mem_ptr, dev_size);
        munmap(device_mem_ptr, dev_size);
    }

    return 0;
}

int main(int argc, char* argv[]) {
    if (parse_args(argc, argv)) {
        return 0;
    }

    if (wait_function == 1)
        rdtsc_overhead = compute_rdtsc_latency();

    pthread_t thread;
    if (pthread_create(&thread, NULL, task, NULL) != 0) {
        fprintf(stderr, "Failed to create thread\n");
        return 1;
    }

    cpu_set_t cpuset;
    CPU_ZERO(&cpuset);
    CPU_SET(cpu_num, &cpuset);

    if (pthread_setaffinity_np(thread, sizeof(cpu_set_t), &cpuset) != 0) {
        fprintf(stderr, "Failed to set thread affinity\n");
        return 1;
    }

    if (pthread_join(thread, NULL) != 0) {
        fprintf(stderr, "Failed to join thread\n");
        return 1;
    }

    return 0;
}
